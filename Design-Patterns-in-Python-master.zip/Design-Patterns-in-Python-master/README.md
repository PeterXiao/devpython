# Design patterns in Python

A collection of popular design patterns implemented in Python programming language.
