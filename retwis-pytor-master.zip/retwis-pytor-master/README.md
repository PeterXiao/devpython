retwis-pytor
===========

**retwis-pytor** is a *Twitter clone* based on [Redis](http://code.google.com/p/redis/) utilizing the [Tornado](http://www.tornadoweb.org) framework.

Usage
----

    >>> python ./retwis.py

Dependencies
------------
    * Redis (redis.io)
    On Ubuntu/Debian: 
    $ sudo apt-get install redis-server
    $ sudo pip install redis
    * Tornado (tornadoweb.org)
    $ sudo pip install tornado
